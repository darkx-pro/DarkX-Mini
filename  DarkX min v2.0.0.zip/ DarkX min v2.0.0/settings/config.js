module.exports = {
    botName: "DarkX-minBot",
    ownerName: "MrX Dev",
    ownerNumber: "255XXXXXXXXX",
    prefix: ".",
    sessionName: "session",
    status: {
        terminal: true, // Weka true ili pairing code itokee kwenye console
        public: true
    }
};
